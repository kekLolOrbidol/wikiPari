package at.sunilson.wiki_quiz.game.models

/**
 * @author Linus Weiss
 */

data class  Article(val title: String, val pageID: String, var extract: String?, val imageURL : String?)