package at.sunilson.wiki_quiz.shared

/**
 * Created by linus on 24.02.2018.
 */

const val ANSWER_POSSIBILITIES = 4
const val QUESTION_AMOUNT = 10
const val EXTRA_IMAGE_THRESHOLD = 2

const val ANSWERED_DIALOG = 0
const val GAME_OVER_DIALOG = 1
const val QUIT_DIALOG = 2