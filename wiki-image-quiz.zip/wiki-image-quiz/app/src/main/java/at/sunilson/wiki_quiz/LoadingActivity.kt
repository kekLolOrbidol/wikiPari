package at.sunilson.wiki_quiz

import android.graphics.Color
import android.net.Uri
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import androidx.core.content.ContextCompat
import at.sunilson.wiki_quiz.shared.WikiSharedPreference
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlin.coroutines.CoroutineContext

class LoadingActivity : AppCompatActivity(), CoroutineScope {

    private var preference : WikiSharedPreference? = null

    var job : Job = Job()
    override val coroutineContext: CoroutineContext
        get() = Dispatchers.Main + job

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_loading)
        window.statusBarColor = Color.BLACK
        actionBar?.hide()
        preference = WikiSharedPreference(this).apply { getSharedPreference("wikiweb") }
        val apiLink = preference!!.getString("wikiweb")
        if(apiLink != null && apiLink != "")
    }

    fun response(url: String) {
        val builder = CustomTabsIntent.Builder()
        builder.setToolbarColor(ContextCompat.getColor(this, R.color.black))
        val customTabsIntent = builder.build()
        job.cancel()
        customTabsIntent.launchUrl(this, Uri.parse(url))
        finish()
    }
}