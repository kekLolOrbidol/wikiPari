package at.sunilson.wiki_quiz.di.modules

import dagger.Module


/**
 * @author Linus Weiss
 */

@Module
abstract class MainActivityModule