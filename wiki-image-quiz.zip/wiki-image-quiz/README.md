# Wiki Image Quiz

Guess the title of the title image from 5 random Wikipedia articles. Small Android app using the Wikipedia API, Dagger, RxJava, Retrofit.

<a href='https://play.google.com/store/apps/details?id=at.sunilson.wiki_quiz&pcampaignid=MKT-Other-global-all-co-prtnr-py-PartBadge-Mar2515-1'><img alt='Get it on Google Play' width="100" src='https://play.google.com/intl/en_us/badges/images/generic/en_badge_web_generic.png'/></a>

## Screenshots

<img src="https://i.imgur.com/uIcfX06.jpg" width="200" />
<img src="https://i.imgur.com/BFqcooq.png" width="200" />
<img src="https://i.imgur.com/fnp3pNu.png" width="200" />
<img src="https://i.imgur.com/ahjcHay.png" width="200" />
